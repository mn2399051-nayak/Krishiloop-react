import { useState } from "react";
import { processors, matchFactors, weights, factorNames, score } from "../data.js";

const pct = (v) => Math.round(v * 100);

export default function SmartMatching() {
  const [selected, setSelected] = useState("P1");
  const ranked = [...processors]
    .map((p) => ({ ...p, score: score(matchFactors[p.id]) }))
    .sort((a, b) => b.score - a.score);
  const chosen = processors.find((p) => p.id === selected);
  const f = matchFactors[selected];

  return (
    <div className="grid2" id="matching">
      <div className="panel">
        <h3>Best processor matches</h3>
        <p className="sub">Select a lot to see why it was matched</p>
        <div>
          {ranked.map((p) => (
            <button
              key={p.id}
              className="match"
              aria-pressed={p.id === selected}
              onClick={() => setSelected(p.id)}
            >
              <span className="score">{pct(p.score)}</span>
              <span>
                <b>{p.name}</b>
                <br />
                <span style={{ color: "var(--mute)", fontSize: 13 }}>{p.district} &middot; needs {p.need} t</span>
              </span>
            </button>
          ))}
        </div>
      </div>

      <div className="panel">
        <h3>Why this match: Lot L-104 to {chosen.name}</h3>
        <p className="sub">Weighted score, weights are configurable</p>
        {Object.keys(weights).map((k) => (
          <div className="bar" key={k}>
            <span>{factorNames[k]}</span>
            <div><i style={{ width: `${pct(f[k])}%` }} /></div>
            <b>{pct(f[k])}</b>
          </div>
        ))}
        <p className="sub" style={{ marginTop: 14 }}>
          Match score {pct(score(f))} out of 100, from the weighted factors above.
        </p>
      </div>
    </div>
  );
}
