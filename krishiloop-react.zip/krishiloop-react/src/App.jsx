import Sidebar from "./components/Sidebar.jsx";
import LoopStages from "./components/LoopStages.jsx";
import Kpis from "./components/Kpis.jsx";
import DistrictChart from "./components/DistrictChart.jsx";
import RouteMap from "./components/RouteMap.jsx";
import SmartMatching from "./components/SmartMatching.jsx";
import LotsTable from "./components/LotsTable.jsx";
import { stages, kpis, districts, route, lots } from "./data.js";

export default function App() {
  return (
    <div className="app">
      <Sidebar />
      <main id="top">
        <header className="top">
          <div>
            <h2>Paddy residue this season</h2>
            <p>Sangrur, Patiala and Malerkotla &middot; demo data</p>
          </div>
          <button className="btn" onClick={() => document.getElementById("lots").scrollIntoView({ behavior: "smooth" })}>
            Add residue listing
          </button>
        </header>

        <LoopStages stages={stages} />
        <Kpis kpis={kpis} />

        <div className="grid2">
          <DistrictChart districts={districts} />
          <RouteMap route={route} />
        </div>

        <SmartMatching />
        <LotsTable lots={lots} />
      </main>
    </div>
  );
}
