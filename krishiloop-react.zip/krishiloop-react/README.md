# KrishiLoop Dashboard (React)

A React version of the KrishiLoop hackathon dashboard, built with Vite.

## Folder structure

```
krishiloop-react/
├── index.html            entry HTML page
├── package.json
├── vite.config.js
└── src/
    ├── main.jsx           React root
    ├── App.jsx            page layout, wires components together
    ├── data.js            all demo data lives here — swap for API calls later
    ├── index.css           global styles (colors, layout, responsive rules)
    └── components/
        ├── Sidebar.jsx
        ├── LoopStages.jsx
        ├── Kpis.jsx
        ├── DistrictChart.jsx
        ├── RouteMap.jsx
        ├── SmartMatching.jsx
        └── LotsTable.jsx
```

## Run it locally

You need [Node.js](https://nodejs.org) installed (v18 or later).

1. Unzip this folder and open a terminal inside it.
2. Install dependencies:
   ```
   npm install
   ```
3. Start the dev server:
   ```
   npm run dev
   ```
4. Open the URL it prints (usually `http://localhost:5173`).

## Build for deployment

```
npm run build
```

This creates a `dist/` folder with the production-ready static site, which you
can upload to Vercel, Netlify, GitHub Pages, or any static host.

## Connecting real data

All the numbers on the dashboard come from `src/data.js`. Each export
(`stages`, `kpis`, `districts`, `processors`, `lots`, `route`, etc.) is plain
JSON-shaped data. To connect this to your FastAPI backend:

1. Replace the static export with a `fetch()` call (for example inside a
   `useEffect` in `App.jsx`, or with a small custom hook).
2. Keep the same field names so the components don't need to change.

## Notes

- Styling uses CSS variables in `src/index.css` for both light and dark mode.
- The matching score logic (`score()` in `data.js`) mirrors Section 10.1 of
  the project report: a weighted combination of compatibility, distance,
  quantity fit, timing, capacity and quality.
- This is prototype/demo data only, not a live backend.
